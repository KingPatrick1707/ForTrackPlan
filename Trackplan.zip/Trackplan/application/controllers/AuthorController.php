<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AuthorController extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('AModel');
		$this->load->helper('form');
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->library('form_validation');
	}

	public function index()
	{	$this->load->view('index');
	}
	
	public function handleInsert(){
		if ($this->input->post('submitInsert')){
		
			//set validation rules
			
			$this->form_validation->set_rules('input', 'Enter String', 'required');
			
			//get values from post
			$anInput['input'] = $this->input->post('input');
			
			//check if the form has passed validation
			if (!$this->form_validation->run()){
				//validation has failed, load the form again
				$data["message"] = "Alert there has been an Error!!";
				$this->load->view('displayMessageView', $data);
				return;
			}
			$data["stringData"] = $this->AModel->spiltString($anInput['input']);
			//load the view to display the message
			
			$this->load->view('displayView', $data);
			return;
		}
		$anInput['input'] = "";

		//load the form
		$this->load->view('insertView', $anInput);
	}
}