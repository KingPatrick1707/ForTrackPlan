<?php
class AModel extends CI_Model
{
    function __construct()
    {	parent::__construct();
    }
	
	
	function spiltString($input)
	{
		$result = str_split($input);
		$filteredResult = array_filter($result);
		return $filteredResult;
	}

}
?>