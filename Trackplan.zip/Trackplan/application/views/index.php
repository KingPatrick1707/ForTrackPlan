<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
    <div class="main">
		<br><br><br><br>
		<h1>Trackplan Code Home Page</h1>
		<p>Please click the insert link in header to access the form</a>
		<br><br><br><br>
	</div>

<?php
	$this->load->view('footer'); 
?>