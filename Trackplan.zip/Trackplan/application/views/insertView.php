<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<br>
<div class="main">
		<br><br><br><br>
		<h1>Trackplan Form</h1>
		<p>Enter a string and it will be split into letters</a>
		<br>
	</div>

<?php echo form_open_multipart('AuthorController/handleInsert');
	echo '<br><br>';
	echo 'Enter String :';
	echo form_input('input', $input);


	echo '</br></br>';
	
	echo form_submit('submitInsert', "Submit!");

	echo form_close();
	echo validation_errors();
?>

<?php
	$this->load->view('footer'); 
?>