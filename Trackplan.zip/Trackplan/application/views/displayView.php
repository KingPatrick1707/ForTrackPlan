<?php
	$this->load->view('header'); 
	$this->load->helper('url');
	$base = base_url() . index_page();
	$img_base = base_url()."assets/images/";
?>
<div class="list">
	<br><br>
	<h1 class="main">Display</h1>
	<br><br>
		<?php 
			$arraySize =  count($stringData);
			
			echo "<div align='center'>";
			echo "<table   >";
			for ($x = 0; $x < $arraySize; $x++)
			{
				echo "<tr>";
				for ($a = 0; $a < $arraySize; $a++)
			{
				if($x == $a)
				{
					echo "<td>$stringData[$a]</td>";
				}
				else
				{
					echo "<td></td>";
				}
			}
				echo "</tr>";
			}
			echo "</table>";
			echo "</div>";
			
			?>
   <br><br>
</div>
<?php
	$this->load->view('footer'); 
?>