<footer>
	<p><!----Footer-----></p><!------ Commented out as it is not needed ------->
</footer>

</body>
</html>