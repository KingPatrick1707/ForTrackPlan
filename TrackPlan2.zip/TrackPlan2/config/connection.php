<?php
//Define database Connection Parameters
//for this application
//

//TODO : Make sure connection parameters are correct
$DBServer = '127.0.0.1'; // e.g 'localhost' or '127.0.0.1'
$DBUser   = 'root';  //the MySQL user name
$DBPass   = '';  //the MySQL user password
$DBName   = 'college'; //the MySQL database name
//
?>

