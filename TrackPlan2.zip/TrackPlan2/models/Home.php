<?php
/*
 * Home Class
 * 
 * This class prepares the $data array which contains content
 * used by the view_home
 * 
 * This class uses the $loggedin status to determine which content 
 * to place in the view (Menus etc)  
 * 
 * This class takes care of the menu items for the application depending on 
 * the selected pageID
 * 
 */

class Home extends Model{
	//class properties
        private $pageTitle;
        private $menuNav;
        private $panelHead_1;
        private $stringPanel_1;
        private $panelHead_2;
        private $stringPanel_2;
        private $panelHead_3;
        private $stringPanel_3;
        private $pageID;
	
	//constructor
	function __construct($loggedin,$pageID) 
	{   
            parent::__construct($loggedin);
            
            $this->pageID=$pageID;

            
            $this->setPageTitle();
            $this->setmenuNav();

            //get the LHS panel content
            $this->setPanelHead_1();
            $this->setStringPanel_1();


            //get the Middle panel content
            $this->setPanelHead_2();
            $this->setStringPanel_2();
        
            //get the RHS panel content
            $this->setStringPanel_3();
            $this->setPanelHead_3();
   
	}
        
        //setters
        public function setPageTitle(){
            //get the Middle panel content
            if($this->loggedin){
                $this->pageTitle='Home Page';
            }
            else{        
                $this->pageTitle='Home Page';
            }
        }  
        public function setmenuNav(){
            //set the menu item data
            if($this->loggedin){  //these page options are only available to logged in users
                switch ($this->pageID) {
                    case "student_query":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        //$this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=student_query">Student Query</a>';
                        break;
                    case "student_query_result":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        //$this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=student_query">Student Query</a>';                        
                        break;  
                    case "home":
                        //$this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=student_query">Enter String</a>';
                        break;
                     
                    default:
                        //$this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=student_query">Enter String</a>';
                        break;                   
                } 
            }
            else{ //not logged in menu
                $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register</a>';
                $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login</a>';
            }
        }   
        public function setPanelHead_1(){
            //set the LHS panel content
            if($this->loggedin){
                $this->panelHead_1='<h3>Trackplan2</h3>';
            }
            else{        
                $this->panelHead_1='<h3>Trackplan2</h3>';
            }           
            
        }        
        public function setStringPanel_1(){
            if($this->loggedin){
                $this->stringPanel_1='<h4>Overview</h4>';
                $this->stringPanel_1.='<p>Trackplan2 demonstrates an example of an MVC system that takes in a string and outputs it in an diagonal line .'; 
                $this->stringPanel_1.='<p>You are currently logged in.';  
            }
            else{        
                $this->stringPanel_1='<h4>Overview</h4>';
                $this->stringPanel_1.='<p>Trackplan2 demonstrates an example of an MVC system that takes in a string and outputs it in an diagonal line .';
                $this->stringPanel_1.='<p>You are NOT logged in.';  
            } 
        }         
        public function setPanelHead_2(){
            //get the Middle panel content
            if($this->loggedin){
                $this->panelHead_2='<h3>Welcome</h3>';
            }
            else{        
                $this->panelHead_2='<h3>Please register or login</h3>';
            }
        }  
        public function setStringPanel_2(){
            //get the Middle panel content
            if($this->loggedin){
                $this->stringPanel_2='Thank you for logging in successfully to the Trackplan2. Please use the link above in the header to access the form.';
            }
            else{        
                $this->stringPanel_2='Please use the link above to login or register.';
            }
        }          
        public function setPanelHead_3(){
            if($this->loggedin){
                $this->panelHead_3='<h3>Side Notes</h3>';
            }
            else{        
                $this->panelHead_3='<h3>Side Notes</h3>';
            } 
        }        
        public function setStringPanel_3(){
            if($this->loggedin){
                $this->stringPanel_3='';
                $this->stringPanel_3.='<p>The reason I have sent two versions of the application is to demonstrate how flexible and comfortable I am at adapting to different MVC frameworks as well as CSS and/or Bootstrap.</p>';
            }
            else{        
                $this->stringPanel_3='';
                $this->stringPanel_3.='<p>The reason I have sent two versions of the application is to demonstrate how flexible and comfortable I am at adapting to different MVC frameworks as well as CSS and/or Bootstrap.</p>';
            } 
        }         

        
        //getters
        public function getPageTitle(){return $this->pageTitle;}
        public function getMenuNav(){return $this->menuNav;}
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getPanelHead_2(){return $this->panelHead_2;}
        public function getStringPanel_2(){return $this->stringPanel_2;}
        public function getPanelHead_3(){return $this->panelHead_3;}
        public function getStringPanel_3(){return $this->stringPanel_3;}
        
        

        
}//end class
        