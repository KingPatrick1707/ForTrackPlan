<?php

class Student extends Model{
	//class properties
       
        private $panelHead_1;//String: used by the view
        private $stringPanel_1;//String: used by the view
        
        private $panelHead_2;//String: used by the view
        private $stringPanel_2;//String: used by the view
        
        private $pageID;//String: used by the view
        private $studentID; //String : currently selected student ID nr.
        private $db; //MySQLi Class object - connection to MySQL database
	
	//constructor
	function __construct($loggedin,$pageID,$studentID,$db) 
	{   
            //class properties based on constructor arguments
            parent::__construct($loggedin);
            $this->studentID=$studentID;
            $this->db=$db;
            $this->pageID=$pageID;
            

            //get the panel 1 content
            $this->setPanelHead_1();
            $this->setStringPanel_1();
        
            //get the panel 2 content
            $this->setStringPanel_2();
            $this->setPanelHead_2();
	}
      
   
        //setters panel 1
        public function setPanelHead_1(){
            //get the Middle panel content
            if($this->pageID=='student_query'){
                $this->panelHead_1='<h3>Trackplan2 Form</h3>';
            }
            else{        
                $this->panelHead_1='<h3>Trackplan2 Form</h3>';
            }
        }        
        public function setStringPanel_1(){
            //get the panel content
                $this->stringPanel_1 = file_get_contents('forms/studentQueryForm.html');  //this reads an external form file into the string
        }        
        
        //setters Panel 2
        public function setPanelHead_2(){
            switch ($this->pageID) {
                case "student_query":
                    $this->panelHead_2='<h3>Trackplan2 Result Panel</h3>';
                    break;
                case "student_query_result":
                    $this->panelHead_2='<h3>Result for String '.$this->studentID.'</h3>';
                    break;  
                 default:
                    $this->panelHead_2='<h3>Result Panel</h3>';
                    break;                   
            }         
        } 
        public function setStringPanel_2(){        
            switch ($this->pageID) {
                case "student_query":
                    $this->stringPanel_2='';
                    $this->stringPanel_2.='<p>Enter a string in the form. Results will appear here</p>'; 
                    break;
                case "student_query_result":
                    $this->getResult();
                    //$this->getStudentByID();
                    break;
                 default:
                    $this->panelHead_2='<h3>Result will display here</h3>';
                    break;                   
            }           
        } 
        private function getResult(){
            $input = $this->studentID;
            $result = str_split($input);
            $filteredResult = array_filter($result);
            
            $arraySize =  count($filteredResult);
			
            $this->stringPanel_2.= "<div align='center'>";
            $this->stringPanel_2.= "<table   >";
            for ($x = 0; $x < $arraySize; $x++)
            {
                    $this->stringPanel_2.= "<tr>";
                    for ($a = 0; $a < $arraySize; $a++)
            {
                    if($x == $a)
                    {
                            $this->stringPanel_2.= "<td>$filteredResult[$a]</td>";
                    }
                    else
                    {
                            $this->stringPanel_2.= "<td></td>";
                    }
            }
                    $this->stringPanel_2.= "</tr>";
            }
            $this->stringPanel_2.= "</table>";
            $this->stringPanel_2.= "</div>";
        }
        
        //public accessible getter functions
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getPanelHead_2(){return $this->panelHead_2;}
        public function getStringPanel_2(){return $this->stringPanel_2;}
        public function getStudentID(){return $this->studentID;}
      
        
}//end class
        