<?php
/**
 * Description of MainController
 * This is the main controller class for the web applicaiton
 *
 * 
 */
class MainController extends Controller{
    
        //properties
        private $pageID;  //String : containing the name of the requested page
        private $db; //MySQLi connection object
        private $data; //Array containing content data for the view
    
	//constructor
	function __construct($loggedin,$db) 
	{   
           parent::__construct($loggedin);
           $this->db=$db;
           $this->processView();  //get the requested next page
           $this->updateView(); //a switch to load the model and update the view
           $this->debugInfo(); //if debug is turned on display the debug info
           $this->data=[]; //initialise an empty array  [this is only accessed in debug mode]
	}
          
        //methods
        public function processView(){
            //This main controller handles all page requests vis the URL - GET Methos
            //$_GET will contain the selected pageID 
            //If the page is loaded for the first time then the $_GET array is empty
            //so a default value is set for $this->pageID
            if (isset($_GET['pageID'])){  //get the value of pageID from $_GET array
                $this->pageID=$_GET['pageID'];
            }
            else{  //no value passed through URL to $_GET array
                $this->pageID='noPageSelected';  //this will execute the default
            }
        }
        public function updateView(){
            //this SWITCH is the main selector of the next page to load
            switch ($this->pageID) {
                case "home":
                    //get the model
                    $home=new Home($this->loggedin,$this->pageID);
                    
                    //get the content from the model - put into the $data array for the view:
                    $data=[];  //initialise an empty data array
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();       // an array of menu items and associated URLS
                    $data['stringPanel_1'] =$home->getStringPanel_1();     // A string intended of the Left Hand Side of the page
                    $data['stringPanel_2'] =$home->getStringPanel_2();     // A string intended of the Left Hand Side of the page
                    $data['stringPanel_3'] =$home->getStringPanel_3();     // A string intended of the Right Hand Side of the page                    
                    $data['panelHead_1']=$home->getPanelHead_1();// A string containing the LHS panel heading/title
                    $data['panelHead_3']=$home->getPanelHead_3();// A string containing the RHS panel heading/title
                    $data['panelHead_2']=$home->getPanelHead_2(); 
                    $this->data=$data; //put the $data array into the class property do it can be accedded in DEBUG mode
                    //
                    //display the view
                    include_once 'views/view_3_panel.php';  //load the view
                    break;
                case "student_query":
                    //get the models
                    $home=new Home($this->loggedin,$this->pageID); 
                    $studentQuery=new Student($this->loggedin,$this->pageID,NULL,$this->db);
                    
                    //get the content from the model - put into the $data array for the view:
                    $data=[];  //initialise an empty data array
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();       // an array of menu items and associated URLS
                    $data['panelHead_1']=$studentQuery->getPanelHead_1(); 
                    $data['stringPanel_1'] =$studentQuery->getStringPanel_1();     // A string intended of the Left Hand Side of the page
                    $data['panelHead_2']=$studentQuery->getPanelHead_2();// A string containing the RHS panel heading/title
                    $data['stringPanel_2'] =$studentQuery->getStringPanel_2();     // A string intended of the Right Hand Side of the page
                    $this->data=$data; //put the $data array into the class property do it can be accedded in DEBUG mode
                    
                    //display the view
                    include_once 'views/view_2_panel.php'; //load the view
                    break;
                case "student_query_result":
                    //get the selected student ID from the transcript query form
                    $studentID=$_POST['studentID'];

                    //get the models
                    $home=new Home($this->loggedin,$this->pageID); 
                    $studentQuery=new Student($this->loggedin,$this->pageID,$studentID,$this->db); 
                    $data=[];  //initialise an empty data array
                    
                    //get the content from the model - put into the $data array for the view:
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();       // an array of menu items and associated URLS
                    $data['panelHead_1']=$studentQuery->getPanelHead_1(); 
                    $data['stringPanel_1'] =$studentQuery->getStringPanel_1();     // A string intended of the Left Hand Side of the page
                    $data['panelHead_2']=$studentQuery->getPanelHead_2();// A string containing the RHS panel heading/title
                    $data['stringPanel_2'] =$studentQuery->getStringPanel_2();     // A string intended of the Right Hand Side of the page
                    $this->data=$data; //put the $data array into the class property do it can be accedded in DEBUG mode
                    
                    //display the view
                    include_once 'views/view_2_panel.php'; //load the view
                    break;                                    
                
                default:
                    //get the model
                    $home=new Home($this->loggedin,$this->pageID);

                    //get the content from the model - put into the $data array for the view:
                    $data=[];  //initialise an empty data array
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();       // an array of menu items and associated URLS
                    $data['stringPanel_1'] =$home->getStringPanel_1();     // A string intended of the Left Hand Side of the page
                    $data['stringPanel_2'] =$home->getStringPanel_2();     // A string intended of the Left Hand Side of the page
                    $data['stringPanel_3'] =$home->getStringPanel_3();     // A string intended of the Right Hand Side of the page
                    $data['panelHead_1']=$home->getPanelHead_1();// A string containing the LHS panel heading/title
                    $data['panelHead_2']=$home->getPanelHead_2();
                    $data['panelHead_3']=$home->getPanelHead_3();// A string containing the RHS panel heading/title
                    $this->data=$data; //put the $data array into the class property do it can be accedded in DEBUG mode
                    
                    //display the view
                    include_once 'views/view_3_panel.php';  
                    break;
            }
        }
        private function debugInfo(){
            if(__DEBUG){
                echo '<!-- The Debug SECTION -->';
                echo '<section style="background-color: #BBBBBB">';
                echo '<div class="container">';
                echo '<h2>Web Application Debug information</h2><br>';
                echo '<h3>Controller (CLASS) properties</h3>';
                echo '$loggedin ='.$this->loggedin.'<br>';
                echo '$pageID   ='.$this->pageID.'<br>';
                echo '<h3>Super Global Array</h3>';
                echo '<h4>$_GET Arrays</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_GET as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';

                echo '<h4>$_POST Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_POST as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                echo '<h4>$_COOKIE Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_COOKIE as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                echo '<h4>$_SESSION Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_SESSION as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
 
                echo '<h4>$data Array (data passed to VIEW)</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($this->data as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                
                echo '</div>';
                echo '</section>';
            }
        }    
 
}
